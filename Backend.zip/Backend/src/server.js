const app = require("./app");
const env = require("./config/enviroment");
const con = require("./config/db");



app.listen(env.PORT, () => {
    console.log(`Server is running on port http://localhost:${env.PORT}`);
});