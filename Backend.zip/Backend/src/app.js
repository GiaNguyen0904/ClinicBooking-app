const express = require("express");
const cors = require("cors");

const scheduleRoutes = require("./routes/schedule.routes");
const appointmentRoutes = require('./routes/appointment.routes');
const medicalRecordRoutes = require("./routes/medical-record.routes");
const userRoutes = require("./routes/user.routes");

const app = express();

app.use(cors());
app.use(express.json());

app.use('/api/users', userRoutes);
app.use("/api/schedules", scheduleRoutes);
app.use('/api/appointments', appointmentRoutes);
app.use("/api/medical-records", medicalRecordRoutes);


app.get("/", (req, res) => {
  res.send("API running...");
});

module.exports = app;